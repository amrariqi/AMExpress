import { useEffect, useState } from 'react';
import { X, Loader2, Printer, Plus } from 'lucide-react';
import { supabase } from '../supabaseClient';
import { useApp } from '../lib/i18n';
import { calcInvoiceTotals, formatMoney, todayStr } from '../lib/helpers';

export default function CustomerLedger({ customer, companyId, perms, onClose, onChanged }) {
  const { t, isRTL } = useApp();
  const [invoices, setInvoices] = useState(null);
  const [payments, setPayments] = useState(null);
  const [showRecord, setShowRecord] = useState(false);
  const [amount, setAmount] = useState('');
  const [date, setDate] = useState(todayStr());
  const [note, setNote] = useState('');
  const [saving, setSaving] = useState(false);
  const [err, setErr] = useState('');

  async function load() {
    const [{ data: invs }, { data: pays }] = await Promise.all([
      supabase.from('invoices').select('*').eq('customer_id', customer.id).eq('company_id', companyId).order('date'),
      supabase.from('payments').select('*, payment_allocations(*)').eq('customer_id', customer.id).eq('company_id', companyId).order('date'),
    ]);
    setInvoices(invs || []);
    setPayments(pays || []);
  }
  useEffect(() => { load(); }, [customer.id]); // eslint-disable-line react-hooks/exhaustive-deps

  const card = { borderColor: 'var(--line)', borderWidth: 1 };

  if (invoices === null || payments === null) {
    return (
      <div className="fixed inset-0 z-50 flex items-center justify-center" style={{ background: 'rgba(22,35,58,0.5)' }}>
        <Loader2 className="animate-spin" size={28} color="white" />
      </div>
    );
  }

  const invoiceTotals = Object.fromEntries(invoices.map((inv) => [inv.id, calcInvoiceTotals(inv.items, inv.tax_percent, inv.discount).total]));
  const amountPaidByInvoice = {};
  payments.forEach((p) => (p.payment_allocations || []).forEach((a) => {
    amountPaidByInvoice[a.invoice_id] = (amountPaidByInvoice[a.invoice_id] || 0) + Number(a.amount);
  }));

  const totalInvoiced = Object.values(invoiceTotals).reduce((s, v) => s + v, 0);
  const totalPaid = payments.reduce((s, p) => s + Number(p.amount), 0);
  const balance = totalInvoiced - totalPaid; // positive: they owe us · negative: credit they hold with us
  const currency = customer.currency || 'USD';

  const entries = [
    ...invoices.map((inv) => ({ type: 'invoice', date: inv.date, ref: inv.number, amount: invoiceTotals[inv.id] })),
    ...payments.map((p) => ({
      type: 'payment', date: p.date, ref: p.note || t('paymentReceived'), amount: -Number(p.amount),
      allocatedTo: (p.payment_allocations || []).map((a) => invoices.find((i) => i.id === a.invoice_id)?.number).filter(Boolean),
    })),
  ].sort((a, b) => (a.date < b.date ? -1 : a.date > b.date ? 1 : 0));
  let running = 0;
  const timeline = entries.map((e) => { running += e.amount; return { ...e, running }; });

  async function recordPayment() {
    const amt = Number(amount);
    if (!amt || amt <= 0) return;
    setSaving(true); setErr('');
    const { data: paymentRow, error } = await supabase
      .from('payments')
      .insert({ customer_id: customer.id, company_id: companyId, amount: amt, date: date || todayStr(), note: note || null })
      .select().single();
    if (error) { setSaving(false); setErr(error.message); return; }

    let remaining = amt;
    const outstanding = invoices
      .map((inv) => ({ id: inv.id, due: invoiceTotals[inv.id] - (amountPaidByInvoice[inv.id] || 0), date: inv.date }))
      .filter((x) => x.due > 0.005)
      .sort((a, b) => (a.date < b.date ? -1 : 1));

    const allocRows = [];
    for (const inv of outstanding) {
      if (remaining <= 0.005) break;
      const apply = Math.min(inv.due, remaining);
      allocRows.push({ payment_id: paymentRow.id, invoice_id: inv.id, amount: apply, company_id: companyId });
      remaining -= apply;
    }
    if (allocRows.length) await supabase.from('payment_allocations').insert(allocRows);

    setSaving(false); setShowRecord(false); setAmount(''); setNote('');
    load();
    onChanged?.();
  }

  return (
    <div className="fixed inset-0 z-50 flex items-start justify-center overflow-y-auto p-3 sm:p-6 print:p-0 print:static" style={{ background: 'rgba(22,35,58,0.5)' }}>
      <style>{`
        @media print {
          body * { visibility: hidden; }
          #ledger-print-area, #ledger-print-area * { visibility: visible; }
          #ledger-print-area { position: absolute; inset: 0; width: 100%; }
          .no-print { display: none !important; }
        }
      `}</style>
      <div className="bg-white rounded-2xl w-full max-w-xl my-4 print:rounded-none print:my-0 print:max-w-full" style={card}>
        <div className="flex items-center justify-between p-3 border-b no-print" style={{ borderColor: 'var(--line)' }}>
          <button onClick={() => window.print()} className="flex items-center gap-1.5 text-xs font-bold px-3 py-1.5 rounded-lg text-white" style={{ background: 'var(--teal)' }}>
            <Printer size={14} /> {t('printStatement')}
          </button>
          <button onClick={onClose}><X size={20} /></button>
        </div>

        <div id="ledger-print-area" className="p-6" dir={isRTL ? 'rtl' : 'ltr'}>
          <div className="mb-4">
            <div className="text-lg font-extrabold">{customer.name}</div>
            <div className="text-xs text-ink-soft">{[customer.phone, customer.email].filter(Boolean).join(' · ')}</div>
          </div>

          <div className="grid grid-cols-2 gap-3 mb-5">
            <div className="bg-white border rounded-xl p-3" style={card}>
              <div className="text-xs text-ink-soft mb-1">{balance >= 0 ? t('theyOweUs') : t('creditBalance')}</div>
              <div className="text-lg font-extrabold tabular" style={{ color: balance > 0.005 ? 'var(--brick)' : balance < -0.005 ? 'var(--teal)' : 'inherit' }}>
                {formatMoney(Math.abs(balance), currency)}
              </div>
              {Math.abs(balance) < 0.005 && <div className="text-xs text-ink-soft mt-0.5">{t('settled')}</div>}
            </div>
            <div className="bg-white border rounded-xl p-3" style={card}>
              <div className="text-xs text-ink-soft mb-1">{t('totalPaidSoFar')}</div>
              <div className="text-lg font-extrabold tabular">{formatMoney(totalPaid, currency)}</div>
              <div className="text-xs text-ink-soft mt-0.5">{t('ofInvoiced')} {formatMoney(totalInvoiced, currency)}</div>
            </div>
          </div>

          <div className="text-xs font-bold text-ink-soft mb-2">{t('accountTimeline')}</div>
          {timeline.length === 0 ? (
            <div className="text-sm text-ink-soft text-center py-6">—</div>
          ) : (
            <div className="space-y-1.5 mb-4">
              {timeline.map((e, i) => (
                <div key={i} className="flex items-center gap-2 py-1.5 border-b text-sm" style={{ borderColor: 'var(--line)' }}>
                  <div className="text-xs text-ink-soft tabular w-20 shrink-0">{e.date}</div>
                  <div className="flex-1 min-w-0">
                    <div className="truncate">{e.ref}</div>
                    {e.type === 'payment' && e.allocatedTo?.length > 0 && (
                      <div className="text-xs text-ink-soft truncate">{t('appliedTo')}: {e.allocatedTo.join(', ')}</div>
                    )}
                  </div>
                  <div className="tabular font-bold shrink-0" style={{ color: e.amount > 0 ? 'var(--brick)' : 'var(--teal)' }}>
                    {e.amount > 0 ? '+' : ''}{formatMoney(e.amount, currency)}
                  </div>
                </div>
              ))}
            </div>
          )}

          {perms?.canCreate && (
            <div className="no-print">
              {!showRecord ? (
                <button onClick={() => setShowRecord(true)} className="w-full py-2.5 rounded-lg font-bold text-sm text-white flex items-center justify-center gap-1.5" style={{ background: 'var(--teal)' }}>
                  <Plus size={15} /> {t('recordPayment')}
                </button>
              ) : (
                <div className="border rounded-xl p-3 space-y-2.5" style={{ borderColor: 'var(--line)' }}>
                  <div className="grid grid-cols-2 gap-2.5">
                    <input
                      type="number" min="0" step="0.01" placeholder={t('amount')} autoFocus
                      className="px-3 py-2 rounded-lg border text-sm" style={{ borderColor: 'var(--line)', borderWidth: 1 }}
                      value={amount} onChange={(e) => setAmount(e.target.value)}
                    />
                    <input
                      type="date" className="px-3 py-2 rounded-lg border text-sm" style={{ borderColor: 'var(--line)', borderWidth: 1 }}
                      value={date} onChange={(e) => setDate(e.target.value)}
                    />
                  </div>
                  <input
                    placeholder={t('paymentNote')} className="w-full px-3 py-2 rounded-lg border text-sm"
                    style={{ borderColor: 'var(--line)', borderWidth: 1 }} value={note} onChange={(e) => setNote(e.target.value)}
                  />
                  <div className="text-xs text-ink-soft">{t('autoAllocateHint')}</div>
                  {err && <div className="text-xs" style={{ color: 'var(--brick)' }}>{err}</div>}
                  <div className="flex gap-2">
                    <button onClick={() => setShowRecord(false)} className="flex-1 py-2 rounded-lg font-bold text-sm" style={{ border: '1px solid var(--line)' }}>{t('cancel')}</button>
                    <button onClick={recordPayment} disabled={saving || !Number(amount)} className="flex-1 py-2 rounded-lg font-bold text-sm text-white disabled:opacity-50" style={{ background: 'var(--teal)' }}>{t('save')}</button>
                  </div>
                </div>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
